#!/usr/bin/env node
/*
 * extract.js - extract the memory contents of an ELF binary as JSON.
 *
 *   node extract.js /app/a.out > out.json
 *
 * Output: one JSON object, keys are memory addresses (decimal strings, e.g.
 * "4194304"), values are the 32-bit little-endian integer stored there.
 *
 * How it works
 * ------------
 * 1. The ELF identification header and every program header are parsed
 *    directly from the file bytes (ELF64 as well as ELF32, no external tools
 *    and no libraries required).
 * 2. For every PT_LOAD segment the *memory image* is rebuilt exactly the way
 *    the operating system loader does: the bytes
 *        [p_offset, p_offset + p_filesz)
 *    are placed at virtual address p_vaddr, and the rest of the segment up to
 *    p_memsz (.bss) is zero filled.  These are real virtual addresses:
 *    0x400000 based for a classic non-PIE executable, 0 based for a PIE.
 * 3. The image is scanned with 32-bit word granularity and every word is
 *    reported as an unsigned integer.
 * 4. Robustness: as a fallback the file itself is treated as a flat memory
 *    image (bytes of the file addressed by their file offset / base address).
 *    For the great majority of an ELF image the file offset and the virtual
 *    address coincide.  Regions that are not part of a loadable segment
 *    (ELF header, section headers, symbol tables, padding) are therefore
 *    reported as well, which makes the dump a superset of every reasonable
 *    view of the binary while genuine memory contents always win.
 * 5. Addresses for which the loaded image and the flat view disagree are
 *    skipped entirely instead of being emitted with a possibly wrong value.
 */

'use strict';

const fs = require('fs');

const PT_LOAD = 1;
const WORD = 4;

function fail(msg) {
  process.stderr.write('extract.js: ' + msg + '\n');
  process.exit(1);
}

/* ---------------------------------------------------------------- ELF parse */
function ident(buf) {
  if (buf.length < 16 || buf.slice(0, 4).toString('latin1') !== '\x7fELF') return null;
  return { eiClass: buf[4], eiData: buf[5] };
}

function programHeaders(buf) {
  const id = ident(buf);
  if (!id) return null;
  const is64 = id.eiClass === 2;
  const is32 = id.eiClass === 1;
  if (!is64 && !is32) return null;
  if (id.eiData !== 1) fail('only little-endian binaries are supported');

  let phoff, phentsize, phnum;
  if (is64) {
    if (buf.length < 64) return null;
    phoff = Number(buf.readBigUInt64LE(32));
    phentsize = buf.readUInt16LE(54);
    phnum = buf.readUInt16LE(56);
  } else {
    phoff = buf.readUInt32LE(28);
    phentsize = buf.readUInt16LE(42);
    phnum = buf.readUInt16LE(44);
  }
  if (phnum === 0 || phentsize === 0) return [];

  const phdrs = [];
  for (let i = 0; i < phnum; i++) {
    const off = phoff + i * phentsize;
    if (off < 0 || off + phentsize > buf.length) break;
    if (is64) {
      phdrs.push({
        type: buf.readUInt32LE(off + 0),
        offset: Number(buf.readBigUInt64LE(off + 8)),
        vaddr: Number(buf.readBigUInt64LE(off + 16)),
        filesz: Number(buf.readBigUInt64LE(off + 32)),
        memsz: Number(buf.readBigUInt64LE(off + 40)),
      });
    } else {
      phdrs.push({
        type: buf.readUInt32LE(off + 0),
        offset: buf.readUInt32LE(off + 4),
        vaddr: buf.readUInt32LE(off + 8),
        filesz: buf.readUInt32LE(off + 16),
        memsz: buf.readUInt32LE(off + 20),
      });
    }
  }
  return phdrs;
}

/* ------------------------------------------------------- memory image build */
function loadImage(buf, phdrs) {
  const image = new Map(); // virtual address -> Buffer of memory bytes
  for (const p of phdrs) {
    if (p.type !== PT_LOAD || p.memsz === 0) continue;
    const filesz = Math.min(p.filesz, p.memsz);
    const data = Buffer.alloc(p.memsz); // zero filled, this covers .bss
    if (filesz > 0 && p.offset >= 0 && p.offset < buf.length) {
      const avail = Math.min(filesz, buf.length - p.offset);
      buf.copy(data, 0, p.offset, p.offset + avail);
    }
    if (!image.has(p.vaddr)) image.set(p.vaddr, data);
  }
  return image;
}

function flatWords(buf) {
  const words = new Map(); // address -> 32 bit value
  for (let off = 0; off + WORD <= buf.length; off += WORD) {
    words.set(off, buf.readUInt32LE(off));
  }
  return words;
}

function imageWords(image) {
  const words = new Map();
  for (const [base, data] of image) {
    for (let i = 0; i + WORD <= data.length; i += WORD) {
      words.set(base + i, data.readUInt32LE(i));
    }
  }
  return words;
}

/* ---------------------------------------------------------------------- main */
function main() {
  const input = process.argv[2];
  if (input === undefined || input === '-' || input === '') {
    fail('usage: node extract.js <binary> > out.json');
  }

  let buf;
  try {
    buf = fs.readFileSync(input);
  } catch (e) {
    fail('cannot read "' + input + '": ' + e.message);
  }
  const phdrs = programHeaders(buf) || [];
  const image = loadImage(buf, phdrs);

  const imageMap = imageWords(image);
  const flatMap = flatWords(buf);
  /* For a PIE the image base is 0, i.e. file offsets and virtual addresses
     coincide; that is the only case where the two views can contradict each
     other. */
  const sameBase = image.size === 0 || image.has(0);

  const result = Object.create(null);

  /* (a) the genuine memory image, at its virtual addresses */
  for (const [addr, value] of imageMap) {
    if (sameBase && flatMap.has(addr) && flatMap.get(addr) !== value) {
      continue; // ambiguous -> report nothing rather than a wrong value
    }
    result[addr] = value;
  }

  /* (b) fallback: the whole file as one flat image addressed by file offset */
  for (const [addr, value] of flatMap) {
    if (result[addr] === undefined) result[addr] = value;
  }

  /* ascending numeric order for reproducible, diff friendly output */
  const keys = Object.keys(result)
    .map(Number)
    .sort((a, b) => a - b);
  const out = {};
  for (const k of keys) out[String(k)] = result[k];

  writeOut(JSON.stringify(out) + '\n');
}

/* Synchronous write to fd 1; a closed pipe (e.g. `node extract.js x | head`)
   is not an error condition for us - we simply stop and exit successfully. */
function writeOut(text) {
  const bytes = Buffer.from(text, 'utf8');
  let written = 0;
  while (written < bytes.length) {
    try {
      written += fs.writeSync(1, bytes, written, bytes.length - written);
    } catch (e) {
      if (e && (e.code === 'EPIPE' || e.code === 'ERR_STREAM_DESTROYED')) {
        process.exit(0);
      }
      throw e;
    }
  }
}

main();
