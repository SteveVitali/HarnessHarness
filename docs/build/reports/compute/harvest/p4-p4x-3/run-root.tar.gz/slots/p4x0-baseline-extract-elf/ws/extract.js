#!/usr/bin/env node
/*
 * extract.js -- extract memory values from an ELF binary.
 *
 * Usage: node extract.js <path-to-elf> > out.json
 *
 * The (static) memory image of the process is reconstructed from the ELF
 * program headers: every PT_LOAD segment is mapped at its virtual address,
 * with the first p_filesz bytes taken from the file and everything up to
 * p_memsz filled with zeroes (this is exactly what happens for .bss).
 *
 * That memory image is then read as little-endian 32-bit words at every
 * 4-byte aligned address, and the result is printed as a JSON object that
 * maps the decimal address to its integer value.
 */
'use strict';

const fs = require('fs');

const PT_LOAD = 1;
const SHT_NOBITS = 8;
const SHF_ALLOC = 0x2;

function fail(msg) {
  process.stderr.write('extract.js: ' + msg + '\n');
  process.exit(1);
}

function alignUp(x, a) {
  return Math.floor((x + a - 1) / a) * a;
}

function main() {
  const path = process.argv[2];
  if (!path) fail('usage: node extract.js <elf-file>');

  let buf;
  try {
    buf = fs.readFileSync(path);
  } catch (e) {
    fail('cannot read "' + path + '": ' + e.message);
  }
  if (buf.length < 52) fail('file too small to be an ELF file');

  // --- ELF identification -------------------------------------------------
  if (buf.readUInt32BE(0) !== 0x7f454c46) fail('not an ELF file (bad magic)');
  const klass = buf[4]; // 1 = ELF32, 2 = ELF64
  const data = buf[5]; // 1 = little endian
  if (klass !== 1 && klass !== 2) fail('unsupported ELF class');
  if (data !== 1) fail('only little-endian ELF files are supported');
  const is64 = klass === 2;

  // --- Header layout ------------------------------------------------------
  const e_phoff = is64 ? num(buf.readBigUInt64LE(0x20)) : buf.readUInt32LE(0x1c);
  const e_phentsize = is64 ? buf.readUInt16LE(0x36) : buf.readUInt16LE(0x2a);
  const e_phnum = buf.readUInt16LE(is64 ? 0x38 : 0x2c);

  const loads = [];

  // --- Preferred source: PT_LOAD program headers --------------------------
  if (e_phoff && e_phentsize && e_phnum) {
    for (let i = 0; i < e_phnum; i++) {
      const off = e_phoff + i * e_phentsize;
      if (off + e_phentsize > buf.length) break;
      const pType = buf.readUInt32LE(off);
      if (pType !== PT_LOAD) continue;
      const seg = is64
        ? {
            offset: num(buf.readBigUInt64LE(off + 8)),
            vaddr: num(buf.readBigUInt64LE(off + 16)),
            filesz: num(buf.readBigUInt64LE(off + 32)),
            memsz: num(buf.readBigUInt64LE(off + 40)),
          }
        : {
            offset: buf.readUInt32LE(off + 4),
            vaddr: buf.readUInt32LE(off + 8),
            filesz: buf.readUInt32LE(off + 16),
            memsz: buf.readUInt32LE(off + 20),
          };
      if (seg.memsz <= 0) continue;
      loads.push(seg);
    }
  }

  // --- Fallback: derive the image from the allocatable sections -----------
  if (loads.length === 0) {
    const shoff = is64 ? num(buf.readBigUInt64LE(0x28)) : buf.readUInt32LE(0x20);
    const shentsize = is64 ? buf.readUInt16LE(0x3a) : buf.readUInt16LE(0x2e);
    const shnum = buf.readUInt16LE(is64 ? 0x3c : 0x30);
    if (!shoff || !shentsize || !shnum) fail('cannot determine the memory layout');
    const segs = [];
    for (let i = 0; i < shnum; i++) {
      const off = shoff + i * shentsize;
      if (off + shentsize > buf.length) break;
      const shType = buf.readUInt32LE(off + 4);
      const shFlags = is64 ? num(buf.readBigUInt64LE(off + 8)) : buf.readUInt32LE(off + 8);
      if (!(shFlags & SHF_ALLOC)) continue;
      const shAddr = is64 ? num(buf.readBigUInt64LE(off + 16)) : buf.readUInt32LE(off + 16);
      const shOffset = is64 ? num(buf.readBigUInt64LE(off + 24)) : buf.readUInt32LE(off + 24);
      const shSize = is64 ? num(buf.readBigUInt64LE(off + 32)) : buf.readUInt32LE(off + 32);
      if (shSize <= 0) continue;
      if (shType === SHT_NOBITS) {
        segs.push({ offset: null, vaddr: shAddr, filesz: 0, memsz: shSize });
      } else {
        segs.push({ offset: shOffset, vaddr: shAddr, filesz: shSize, memsz: shSize });
      }
    }
    segs.sort((a, b) => a.vaddr - b.vaddr);
    loads.push.apply(loads, segs);
  }

  if (loads.length === 0) fail('no loadable memory found');
  loads.sort((a, b) => a.vaddr - b.vaddr);

  // --- Read one little-endian 32-bit word from the memory image -----------
  function wordAt(addr) {
    for (const seg of loads) {
      if (addr < seg.vaddr) continue;
      const inSeg = addr - seg.vaddr;
      if (inSeg + 4 > seg.memsz) continue;
      let value = 0;
      for (let i = 0; i < 4; i++) {
        const rel = inSeg + i;
        if (rel < seg.filesz) {
          const fileOff = (seg.offset === null ? 0 : seg.offset) + rel;
          if (fileOff < buf.length) {
            value |= buf.readUInt8(fileOff) << (8 * i);
            continue;
          }
        }
        // Beyond the file contents (e.g. .bss) memory is zero.
      }
      return value >>> 0;
    }
    return null;
  }

  // --- Emit every 4-byte aligned word of the image ------------------------
  const result = {};
  const emitted = new Set();
  for (const seg of loads) {
    const start = alignUp(seg.vaddr, 4);
    const end = seg.vaddr + seg.memsz;
    for (let addr = start; addr + 4 <= end; addr += 4) {
      if (emitted.has(addr)) continue;

      // Skip words that straddle two mappings so that we never emit a value
      // that was stitched together from unrelated regions.
      let ok = false;
      for (const seg2 of loads) {
        if (addr >= seg2.vaddr && addr + 4 <= seg2.vaddr + seg2.memsz) {
          ok = (addr >= alignUp(seg2.vaddr, 4));
          if (ok) break;
        }
      }
      if (!ok) continue;

      const value = wordAt(addr);
      if (value === null) continue;
      result[addr] = value;
      emitted.add(addr);
    }
  }

  process.stdout.write(JSON.stringify(result));
}

// Number() wrapper that keeps values below 2^53 exact.
function num(bigint) {
  return typeof bigint === 'bigint' ? Number(bigint) : bigint;
}

main();
